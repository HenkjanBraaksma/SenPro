/*
perceptron.cpp - Simple library for including perceptrons in Arduino code.
Created by Henkjan Braaksma, 30-10-17
*/

#include "Arduino.h"
#include "perceptron.h"
#include "math.h"

//Create a new Perceptron with a basic 0.5 threshold.
Perceptron::Perceptron()
{
	_value = 0.0;
	_threshold = 0.5;
}

//Create a new Perceptron with a custom threshold.
Perceptron::Perceptron(float threshold)
{
	_value = 0.0;
	_threshold = threshold;
}

//Add an input to the perceptron, multiplied by the connection weight.
void Perceptron::Input(float input, float weight)
{
	_value += (input * weight);
}

//Return the value of the perceptron.
float Perceptron::Value()
{
	return _value;
}

float Perceptron::Output()
{
	if(_value > _threshold)
	{
		return 1.0;
	}
	else
	{
		return 0.0;
	}
}

void Perceptron::Reset()
{
	_value = 0.0;
}
