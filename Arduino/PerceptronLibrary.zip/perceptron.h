/*
perceptron.h - Simple library for including perceptrons in Arduino code.
Created by Henkjan Braaksma, 30-10-17
*/
#ifndef perceptron_h
#define perceptron_h

#include "Arduino.h"

class Perceptron
{
public:
	Perceptron();
	Perceptron(float threshold);
	void Input(float input, float weight);
	float Value();
	float Output();
	void Reset();

private:
	float _value;
	float _threshold;
};

#endif